<?php
session_start();
require_once('tcpdf/tcpdf.php');
require_once('../modelo/consultasDonaciones.php');
include_once("../modelo/Usuario.php");

if (!isset($_SESSION["usuario"])) {
    die("Sesión expirada. Inicia sesión.");
}

$usuario = unserialize($_SESSION["usuario"]);
$idUsuario = $usuario->getIdUsuario();
$esProyecto = isset($_GET['idProyecto']);
$idProponente = $esProyecto ? $_GET['idProyecto'] : null;

// Registramos donación, obtenemos id y descripción
$resultado = registrarDonacionConFicha($idUsuario, $idProponente);
$idDonacion = $resultado['idDonacion'];
$tipoDonacion = $resultado['tipoDonacion'];
$descripcion = $resultado['descripcion'];

// genera el pdf de ficha de pago
$pdf = new TCPDF();
$pdf->AddPage();
$referencia = "D" . str_pad($idDonacion, 6, "0", STR_PAD_LEFT);
$codigoBarras = $referencia;

$html = "
<h2 style='text-align:center;'>Ficha de Donación</h2>
<hr>
<p><strong>Nombre:</strong> " . htmlspecialchars($usuario->getNombre()) . "</p>
<p><strong>Tipo de Donación:</strong> " . ucfirst($tipoDonacion) . "</p>
<p><strong>Descripción:</strong> $descripcion</p>
<p><strong>Referencia:</strong> $referencia</p>
<br><br>
<p style='text-align:center;'>Presenta esta ficha al momento de realizar tu donación.</p>
";
$pdf->writeHTML($html, true, false, true, false, '');
$pdf->write2DBarcode($codigoBarras, 'QRCODE,H', 150, 30, 40, 40, [], 'N');
$pdf->Output("FichaDonacion_$referencia.pdf", 'D');
exit;
?>
