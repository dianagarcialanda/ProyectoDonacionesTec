<?php
require_once('../modelo/AccesoDatos.php');

$id = $_GET['id'] ?? null;

if (!$id) {
    echo "ID no proporcionado.";
    exit;
}

$oAD = new AccesoDatos();
if (!$oAD->conectar()) {
    die("Error al conectar a la base de datos.");
}

$sql = "SELECT descripcion, cantidad, foto, comprobante, estado 
        FROM donacionesespecie WHERE idDonacion = :id";
$params = [":id" => $id];

$resultados = $oAD->ejecutarConsulta($sql, $params);

if ($resultados && count($resultados) > 0) {
    $row = $resultados[0];

    echo "<strong>Descripción:</strong> " . htmlspecialchars($row['descripcion']) . "<br>";
    echo "<strong>Cantidad:</strong> " . htmlspecialchars($row['cantidad']) . "<br>";

    if (!empty($row['foto'])) {
        echo "<strong>Foto:</strong><br><img src='uploads/fotos/" . htmlspecialchars($row['foto']) . "' width='100'><br>";
    }

    if (!empty($row['comprobante'])) {
        echo "<strong>Comprobante:</strong> <a href='comprobantes/" . htmlspecialchars($row['comprobante']) . "' target='_blank'>Ver PDF</a><br>";
    }

    echo "<strong>Estado:</strong> " . htmlspecialchars($row['estado']) . "<br><br>";

    echo "<form method='post' action='actualizarEstado.php'>
        <input type='hidden' name='idDonacion' value='" . htmlspecialchars($id) . "'>
        <button type='submit' name='accion' value='aprobado'>Aprobar</button>
        <button type='submit' name='accion' value='rechazado'>Rechazar</button>
    </form>";
} else {
    echo "No se encontró la donación en especie.";
}

$oAD->desconectar();
?>
