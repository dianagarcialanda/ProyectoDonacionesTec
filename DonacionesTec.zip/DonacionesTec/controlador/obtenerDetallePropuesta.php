<?php
require_once('../modelo/AccesoDatos.php');

$id = $_GET['id'] ?? null;

if (!$id) {
    echo "ID no proporcionado.";
    exit;
}

$oAD = new AccesoDatos();
if (!$oAD->conectar()) {
    die("Error al conectar a la base de datos.");
}

$sql = "SELECT descripcion, archivo FROM donacionespropuesta WHERE idDonacion = :id";
$params = [":id" => $id];

$resultados = $oAD->ejecutarConsulta($sql, $params);

if ($resultados && count($resultados) > 0) {
    $row = $resultados[0];

    echo "<strong>Descripción:</strong> " . htmlspecialchars($row['descripcion']) . "<br>";

    if (!empty($row['archivo'])) {
        echo "<strong>Archivo:</strong> <a href='uploads/archivos/" . htmlspecialchars($row['archivo']) . "' target='_blank'>Ver archivo</a><br>";
    }

    echo "<form method='post' action='actualizarEstado.php'>
        <input type='hidden' name='idDonacion' value='" . htmlspecialchars($id) . "'>
        <button type='submit' name='accion' value='aprobado'>Aprobar</button>
        <button type='submit' name='accion' value='rechazado'>Rechazar</button>
    </form>";
} else {
    echo "No se encontró la donación por propuesta.";
}

$oAD->desconectar();
?>
