<?php
session_start();
include_once("modelo/Usuario.php");
require_once("AccesoDatos.php");


if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit;
}


$nombre = $_POST['nombre'] ?? null;
$correo = $_POST['correo'] ?? null;
$telefono = $_POST['telefono'] ?? null;
$direccion = $_POST['direccion'] ?? null;

$oUsu = unserialize($_SESSION["usuario"]);
$idUsuario = $oUsu->getIdUsuario();


if (!$nombre || !$correo || !$telefono || !$direccion) {
    echo "Faltan datos en el formulario.";
    exit;
}

$oAD = new AccesoDatos();
if (!$oAD->conectar()) {
    die("Error de conexión a la base de datos.");
}

// Actualizamos en bdd
$sql = "UPDATE usuarios SET nombre = :nombre, correo = :correo, telefono = :telefono, direccion = :direccion WHERE idUsuario = :idUsuario";
$params = [
    ":nombre" => $nombre,
    ":correo" => $correo,
    ":telefono" => $telefono,
    ":direccion" => $direccion,
    ":idUsuario" => $idUsuario
];

$resultado = $oAD->ejecutarSentencia($sql, $params);
$oAD->desconectar();

if ($resultado) {

    $oUsu->setNombre($nombre);
    $oUsu->setCorreo($correo);
    $oUsu->setTelefono($telefono);
    $oUsu->setDireccion($direccion);
    $_SESSION["usuario"] = serialize($oUsu);

    header("Location: miPerfil.php");
    exit;
} else {
    echo "Error al actualizar los datos del perfil.";
}
?>
