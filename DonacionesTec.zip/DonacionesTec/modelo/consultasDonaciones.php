<?php
require_once("AccesoDatos.php");
$oAccesoDatos = new AccesoDatos();
$oAccesoDatos->conectar();

function obtenerDatosDonacionMonetaria($idDonacion) {
    
    if (!$oAccesoDatos->conectar()) {
        die("Error al conectar con la base de datos.");
    }
    $query = "SELECT dm.monto, dm.metodoPago, u.nombre 
    FROM donacionesmonetarias dm 
    JOIN donaciones d ON dm.idDonacion = d.idDonacion 
    JOIN usuarios u ON d.idUsuario = u.idUsuario 
    WHERE dm.idDonacion = $idDonacion";
    try {
        $resultado = $oAccesoDatos->ejecutarConsulta($query);
        $oAccesoDatos->desconectar();

        if ($resultado && count($resultado) > 0) {
            return [
                "monto" => $resultado[0][0],
                "metodoPago" => $resultado[0][1],
                "nombre" => $resultado[0][2]
            ];
        } else {
            die("No se encontró la donación.");
        }
    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
}


function actualizarNombreComprobante($idDonacion, $nombreArchivo) {
    
    if (!$oAccesoDatos->conectar()) {
        die("Error al conectar con la base de datos.");
    }

    $query ="UPDATE donacionesmonetarias 
    SET comprobante = '$nombreArchivo' 
    WHERE idDonacion = $idDonacion";

    try {
        $oAccesoDatos->ejecutarComando($query);
        $oAccesoDatos->desconectar();
    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
}



function obtenerDetalleEspecieF($id) {
    $oAD = new AccesoDatos();
    if (!$oAD->conectar()) {
        die("Error al conectar a la base de datos.");
    }

    $id = intval($id);
    $query = "SELECT descripcion, cantidad, estado, foto, comprobante 
    FROM donacionesespecie 
    WHERE idDonacion = $id";

    $resultado = $oAD->ejecutarConsulta($query);
    $oAD->desconectar();
    return $resultado;
}

function obtenerDetalleMonetariaF($idDonacion) {
    $oAD = new AccesoDatos();
    if (!$oAD->conectar()) {
        die("Error al conectar a la base de datos.");
    }

    $idDonacion = intval($idDonacion);
    $query = "SELECT monto, metodoPago, comprobante 
    FROM donacionesmonetarias 
    WHERE idDonacion = $idDonacion";

    $resultado = $oAD->ejecutarConsulta($query);
    $oAD->desconectar();
    return $resultado;
}


function obtenerDetallePropuestaF($id) {
    $oAD = new AccesoDatos();
    if (!$oAD->conectar()) {
        die("Error al conectar a la base de datos.");
    }

    $id = intval($id);
    $query = "SELECT dp.descripcion, dp.archivo
    FROM donacionespropuesta dp
    JOIN donaciones d ON dp.idDonacion = d.idDonacion
    WHERE dp.idDonacion = $id";

    $resultado = $oAD->ejecutarConsulta($query);
    $oAD->desconectar();
    return $resultado;
}

function validarCorreo($correo) {
    $oAD = new AccesoDatos();
    if (!$oAD->conectar()) {
        die("Error al conectar a la base de datos.");
    }

    $correo = addslashes($correo);
    $query = "SELECT idUsuario FROM usuarios WHERE correo = '$correo'";
    $resultado = $oAD->ejecutarConsulta($query);
    $oAD->desconectar();

    if ($resultado && count($resultado) > 0) {
        die("Ya existe una cuenta con este correo.");
    }
}

function insertarNuevoUsuario($nombre, $correo, $telefono, $direccion, $fechaNac, $password) {
    $oAD = new AccesoDatos();
    if (!$oAD->conectar()) {
        die("Error al conectar a la base de datos.");
    }

    $nombre = addslashes($nombre);
    $correo = addslashes($correo);
    $telefono = addslashes($telefono);
    $direccion = addslashes($direccion);
    $fechaNac = addslashes($fechaNac);
    $password = addslashes($password);

    $query = "INSERT INTO usuarios 
    (nombre, correo, telefono, direccion, fechaNac, contrasena, rol)
    VALUES ('$nombre', '$correo', '$telefono', '$direccion', '$fechaNac', '$password', 'usuario')";

    try {
        $oAD->ejecutarComando($query);
        $oAD->desconectar();
        header("Location: ../logeo.php");
        exit;
    } catch (Exception $e) {
        echo "Error al registrar: " . $e->getMessage();
    }
}

function obtenerDatosDonacionParaFicha($idDonacion) {
    $oAD = new AccesoDatos();
    if (!$oAD->conectar()) {
        return false;
    }

    $idDonacion = intval($idDonacion);
    $query = "SELECT u.nombre, d.tipoDonacion, d.referencia, p.nombre AS nombreProyecto
    FROM donaciones d
    JOIN usuarios u ON d.idUsuario = u.idUsuario
    LEFT JOIN proyectos p ON d.idProyecto = p.idProyecto
    WHERE d.idDonacion = $idDonacion";

    $resultado = $oAD->ejecutarConsulta($query);
    $oAD->desconectar();

    if ($resultado && count($resultado) > 0) {
        return [
            "nombre" => $resultado[0][0],
            "tipoDonacion" => $resultado[0][1],
            "referencia" => $resultado[0][2],
            "nombreProyecto" => $resultado[0][3]
        ];
    }

    return false;
}


function registrarDonacionConFicha($idUsuario, $idProponente = null) {
    $db = AccesoDatos::getInstancia();
    $conexion = $db->getConexion();

    $tipoDonacion = $idProponente ? "propuesta" : "general";
    $descripcion = "Donación general";

    
    $stmt = $conexion->prepare("INSERT INTO donaciones (idUsuario, tipoDonacion, estado) 
    VALUES (?, ?, 'pendiente')");
    $stmt->execute([$idUsuario, $tipoDonacion]);
    $idDonacion = $conexion->lastInsertId();

    if ($idProponente) {
        $stmtProyecto = $conexion->prepare("
            SELECT dp.descripcion FROM donacionespropuesta dp 
            INNER JOIN donaciones d ON dp.idDonacion = d.idDonacion 
            WHERE d.idUsuario = ? ORDER BY d.idDonacion DESC LIMIT 1
        ");
        $stmtProyecto->execute([$idProponente]);
        $row = $stmtProyecto->fetch(PDO::FETCH_ASSOC);
        $descripcion = $row ? $row['descripcion'] : "Donación al proyecto del usuario ID $idProponente";

        $stmt2 = $conexion->prepare("INSERT INTO donacionespropuesta (idDonacion, descripcion) 
        VALUES (?, ?)");
        $stmt2->execute([$idDonacion, $descripcion]);
    }

    return [
        'idDonacion' => $idDonacion,
        'tipoDonacion' => $tipoDonacion,
        'descripcion' => $descripcion
    ];
}

function obtenerDonacionesPorTipo($tipo) {
    $bd = AccesoDatos::getInstancia();

    if ($tipo === "propuesta") {
        $sql = "
            SELECT u.idUsuario, u.nombre, d.tipoDonacion, d.estado, dp.descripcion
            FROM usuarios u
            JOIN donaciones d ON u.idUsuario = d.idUsuario
            JOIN donacionespropuesta dp ON dp.idDonacion = d.idDonacion
            WHERE d.tipoDonacion = :tipo
        ";
    } else {
        $sql = "
            SELECT u.idUsuario, u.nombre, d.tipoDonacion, d.estado
            FROM usuarios u
            JOIN donaciones d ON u.idUsuario = d.idUsuario
            WHERE d.tipoDonacion = :tipo
        ";
    }

    $params = [":tipo" => $tipo];
    return $bd->consultarDatos($sql, $params);
}

?>
